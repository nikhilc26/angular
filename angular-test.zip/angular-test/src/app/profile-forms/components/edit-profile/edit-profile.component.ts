import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EditProfile } from '../../models/edit-profile';
import { EditProfileService } from '../../services/edit-profile.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css'],
})
export class EditProfileComponent implements OnInit {
  editProfile: EditProfile = new EditProfile();
  constructor(
    private editProfileService: EditProfileService,
    private router: Router
  ) {}

  editProfileSubmit() {
    this.editProfileService.editProfile(this.editProfile).subscribe(
      (res) => {
        console.log('succeess');
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }
  ngOnInit(): void {}
}
