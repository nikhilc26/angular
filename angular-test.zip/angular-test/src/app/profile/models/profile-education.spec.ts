import { ProfileEducation } from './profile-education';

describe('ProfileEducation', () => {
  it('should create an instance', () => {
    expect(new ProfileEducation()).toBeTruthy();
  });
});
