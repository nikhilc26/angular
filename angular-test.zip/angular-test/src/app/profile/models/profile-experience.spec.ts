import { ProfileExperience } from './profile-experience';

describe('ProfileExperience', () => {
  it('should create an instance', () => {
    expect(new ProfileExperience()).toBeTruthy();
  });
});
