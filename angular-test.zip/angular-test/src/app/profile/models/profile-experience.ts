export interface ProfileExperience {
    current: boolean;
    _id: string;
    title: string;
    company: string;
    location: string;
    from: string;
    to: string;
    description: string;
  }