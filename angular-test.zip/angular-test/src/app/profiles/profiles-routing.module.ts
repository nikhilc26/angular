import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfileItemComponent } from './components/profile-item/profile-item.component';
import { ProfilesComponent } from './components/profiles/profiles.component';

const routes: Routes = [
  {
    path: '',
    component: ProfilesComponent,
  },
  {
    path: 'profile-item',
    component: ProfileItemComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfilesRoutingModule {}
