import { Component, OnInit } from '@angular/core';
import { Profile } from '../../models/profiles';
import { ProfilesService } from '../../services/profiles.service';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css']
})
export class ProfilesComponent implements OnInit {
  profile: Profile = new Profile();
  profiles: Profile[];

  constructor(private profilesService: ProfilesService) { }

  showProfiles(){
    console.log("in showProfiles()");
    this.profilesService.loadProfiles().subscribe((res)=>{
      console.log(res);
      this.profiles = res;
    });
  }
  ngOnInit(): void {
    this.showProfiles();
  }

}
