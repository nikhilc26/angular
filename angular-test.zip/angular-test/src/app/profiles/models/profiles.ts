export class User {
    _id: String;
    name: String;
}
export class Profile{
    user: User;
    status: String;
    company: String;
    location:String;
    skills:String;
}
