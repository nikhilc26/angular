import { ProfileItem } from './profile-item';

describe('ProfileItem', () => {
  it('should create an instance', () => {
    expect(new ProfileItem()).toBeTruthy();
  });
});
