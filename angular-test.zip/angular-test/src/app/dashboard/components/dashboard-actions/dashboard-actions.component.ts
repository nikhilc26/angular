import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-actions',
  templateUrl: './dashboard-actions.component.html',
  styleUrls: ['./dashboard-actions.component.css']
})
export class DashboardActionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
